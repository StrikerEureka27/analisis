<?php

 $server = "localhost";
 $user = "DiPablo";
 $pass = "1234";
 $db = "mydb";

 $con = mysqli_connect($server,$user,$pass,$db);
 


?>
