<?php

	include ('conexion.php');

	if(isset($_POST['nombre'])){
		$nombre = $_POST['nombre'];
		$fcompra = $_POST['fcompra'];
		$fvence = $_POST['fvence'];
		$cantidad = $_POST['cantidad'];
		$marca = $_POST['marca'];
		$stipo = $_POST['stipo'];
		$spaquete = $_POST['spaquete'];

		$cant_min = ($cantidad*10)/100;

		$consulta = "INSERT INTO INVENTARIO (NOMBRE,FECHA_COMPRA,FECHA_VENCIMIENTO,CANTIDAD,MARCA,TIPO,MEDIDA,CANTIDAD_MIN) 
		VALUES ('$nombre',DATE('$fcompra'),DATE('$fvence'),$cantidad, '$marca', '$stipo', '$spaquete',$cant_min)";

		$result = mysqli_query($con,$consulta);
		if(!$result){
			die('La consulta fallo :c ');

		}
		echo 'Datos ingresados';
	}


?>



   