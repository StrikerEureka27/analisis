<?php

    include('conexion.php');

    $query = "SELECT *FROM GASTO_FIJO WHERE tipo=1";
    $result = mysqli_query($con,$query);

    if(!$result){
        echo 'consulta fallida '.mysqli_error($con);
    }
    $json = array();
    while($row = mysqli_fetch_row($result)){
        $tri=$row[2]*3;
        $anual=$row[2]*12;
        $json[] = array(
            'id'=>$row[0],
            'nombre' =>$row[1],
            'mensual' =>$row[2],
            'trimestral' =>$tri,
            'anual' =>$anual,
        );
        $tri=0;
        $anual=0;
    }
    $jsonstring = json_encode($json);
    echo $jsonstring;
?>