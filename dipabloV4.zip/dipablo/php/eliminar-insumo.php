<?php

include 'conexion.php';

if(isset($_POST['cantidad'])){

    $cantidad = $_POST['cantidad'];
    $real = $_POST['real'];
    
    $query = "SELECT cantidad, INVENTARIO_id
    FROM  DET_RECETA
    WHERE RECETA_id=(SELECT RECETA_id FROM COSTO_REAL WHERE id=$real);"; 
    $result = mysqli_query($con, $query);

    
    while($fila = mysqli_fetch_row($result)){
        $multi = $cantidad * $fila[0];

        inventario($fila[1],$multi);
            $multi = 0;
        
    }

    


}else{

    echo ':C';
    
}

function inventario($id, $multi){
    $json = array();

    include 'conexion.php';

    $query2 = "SELECT cantidad FROM INVENTARIO WHERE id=$id";
    $result2 = mysqli_query($con, $query2);

    while($fila2 = mysqli_fetch_row($result2)){
        $resta = $fila2[0] - $multi;
        $json[] = array(
            'cant_inve' => $fila2[0], 
            'resta' =>  $resta
        );

        modificar($id, $resta);

    }



    $jsonstring = json_encode($json);
    echo $jsonstring;
    

}

function modificar($id, $resta){
    include 'conexion.php';
    $query3 = "UPDATE INVENTARIO SET cantidad = $resta  WHERE id=$id";
    $result = mysqli_query($con, $query3);
}



?>