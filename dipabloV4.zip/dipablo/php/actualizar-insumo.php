<?php

include 'conexion.php';

if(isset($_POST['id'])){ 


    $id = $_POST['id'];
    $cantidad = $_POST['cantidad'];

    $query = "UPDATE inventario SET cantidad = $cantidad WHERE (id = $id)";
    $result = mysqli_query($con, $query);

}else{
    echo ':c';
}


?>