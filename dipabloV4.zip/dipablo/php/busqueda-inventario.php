<?php

include 'conexion.php';

$search = $_POST['search'];

$query = "SELECT *FROM INVENTARIO WHERE nombre LIKE '$search%'";
$result = mysqli_query($con,$query);

$json = array();
while($fila = mysqli_fetch_row($result)){
    $json[] = array(
        'id' => $fila[0],
        'nombre' => $fila[1],
        'cantidad' => $fila[4]
    );
}

$jsonstring = json_encode($json);
echo $jsonstring;

?>


