<?php

    include('conexion.php');

    $query = "SELECT id FROM mydb.inventario where inventario.cantidad<=inventario.cantidad_min";
    $result = mysqli_query($con,$query);

    if(!$result){
        echo 'consulta fallida '.mysqli_error($con);
    }
    $json = array();
    while($row = mysqli_fetch_row($result)){
        $json[] = array(
            'id'=>$row[0],
        );
    }
    $jsonstring = json_encode($json);
    echo $jsonstring;
?>