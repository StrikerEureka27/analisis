<?php

    include('conexion.php');
    $id = $_POST['id'];
    $men = $_POST['men'];

    $query = "UPDATE GASTO_FIJO SET gasto=$men WHERE id=$id";
    $result = mysqli_query($con,$query);

    if(!$result){
        echo 'consulta fallida '.mysqli_error($con);
    }
    
?>