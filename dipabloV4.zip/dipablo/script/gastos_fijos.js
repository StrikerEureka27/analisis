$(document).ready(function(){

    
    $.ajax({
        url: 'php/GastosExp.php',
        type:'GET',
        success: function(respuesta){
            let menu= JSON.parse(respuesta);   
            let templase = '';
            var tot_men= 0;
            var tot_tri= 0;
            var tot_anual= 0;
            
            menu.forEach(element => {
                templase += `
                <tr>
                    <th scope="row">${element.nombre}</th>
                    <td><input type="text" id="men${element.id}" onkeyup="Calculos(${element.id})" value="${element.mensual}"></td>
                    <td><input type="text" id="tri${element.id}" value="${element.trimestral}" disabled></td>
                    <td><input type="text" id="an${element.id}" value="${element.anual}" disabled></td>
                    <td><button type="button" onclick="Guardar(${element.id}),location.href='gastos_fijos.html'" class="btn btn-success btn-sm"><i class="fas fa-sync-alt"></i></button></td>
                </tr> 
                `
                tot_men=tot_men+(new Number(element.mensual));
                tot_tri=tot_tri+(new Number(element.trimestral));
                tot_anual=tot_anual+(new Number(element.anual));
            });
            templase+=`
            <tr>
                <td bgcolor="92D050" data-label="Datos"><strong>Total</strong></td>
                <td bgcolor="92D050" data-label="Mensual"><input type="text" class="mensual_ge" value="${tot_men}"></input></td>
                <td bgcolor="92D050" data-label="Trimestral"><input id="t_ge" type="text" value="${tot_tri}"></input></td>
                <td bgcolor="92D050" data-label="Anual"><input  type="text" id="a_ge" value="${tot_anual}"></input></td>
                <td bgcolor="92D050" data-label="Anual"></td>
            </tr>
            `
            $('#GastosExp').html(templase);
        }
    })
    $.ajax({
        url: 'php/GastosAdmin.php',
        type:'GET',
        success: function(respuesta){
            let menu= JSON.parse(respuesta);   
            let templase = '';
            var tot_men= 0;
            var tot_tri= 0;
            var tot_anual= 0;
            
            menu.forEach(element => {
                templase += `
                <tr>
                    <th scope="row">${element.nombre}</th>
                    <td><input type="text" id="men${element.id}" onkeyup="Calculos(${element.id})" value="${element.mensual}"></td>
                    <td><input type="text" id="tri${element.id}" value="${element.trimestral}" disabled></td>
                    <td><input type="text" id="an${element.id}" value="${element.anual}" disabled></td>
                    <td><button type="button" onclick="Guardar(${element.id}),location.href='gastos_fijos.html'" class="btn btn-success btn-sm"><i class="fas fa-sync-alt"></i></button></td>
                </tr> 
                `
                tot_men=tot_men+(new Number(element.mensual));
                tot_tri=tot_tri+(new Number(element.trimestral));
                tot_anual=tot_anual+(new Number(element.anual));
            });
            templase+=`
            <tr>
                <td bgcolor="92D050" data-label="Datos"><strong>Total</strong></td>
                <td bgcolor="92D050" data-label="Mensual"><input type="text" value="${tot_men}"></input></td>
                <td bgcolor="92D050" data-label="Trimestral"><input  type="text" value="${tot_tri}"></input></td>
                <td bgcolor="92D050" data-label="Anual"><input  type="text" value="${tot_anual}"></input></td>
                <td bgcolor="92D050" data-label="Anual"></td>
            </tr>
            `
            $('#GastosAdmin').html(templase);
        }
    })
    $.ajax({
        url: 'php/GastosEmpl.php',
        type:'GET',
        success: function(respuesta){
            let menu= JSON.parse(respuesta);   
            let templase = '';
            var tot_men= 0;
            var tot_tri= 0;
            var tot_anual= 0;
            
            menu.forEach(element => {
                templase += `
                <tr>
                    <th scope="row">${element.nombre}</th>
                    <td><input type="text" id="men${element.id}" onkeyup="Calculos(${element.id})" value="${element.mensual}"></td>
                    <td><input type="text" id="tri${element.id}" value="${element.trimestral}" disabled></td>
                    <td><input type="text" id="an${element.id}" value="${element.anual}" disabled></td>
                    <td><button type="button" onclick="Guardar(${element.id}),location.href='gastos_fijos.html'" class="btn btn-success btn-sm"><i class="fas fa-sync-alt"></i></button></td>
                </tr> 
                `
                tot_men=tot_men+(new Number(element.mensual));
                tot_tri=tot_tri+(new Number(element.trimestral));
                tot_anual=tot_anual+(new Number(element.anual));
            });
            templase+=`
            <tr>
                <td bgcolor="92D050" data-label="Datos"><strong>Total</strong></td>
                <td bgcolor="92D050" data-label="Mensual"><input type="text" value="${tot_men}"></input></td>
                <td bgcolor="92D050" data-label="Trimestral"><input  type="text" value="${tot_tri}"></input></td>
                <td bgcolor="92D050" data-label="Anual"><input  type="text" value="${tot_anual}"></input></td>
                <td bgcolor="92D050" data-label="Anual"></td>
            </tr>
            `
            $('#GastosEmpl').html(templase);
        }
    })
    total();
    function total(){
        var m_ge = document.getElementsByClassName("mensual_ge").value;
        //var t_ge = document.getElementById("t_ge").value
        //var a_ge = document.getElementById("a_ge").value
    
        console.log(m_ge);
    }
    
    
});

function Calculos(id){

    var nom1 = '#men'+id;
    var nom2 = 'tri'+id;
    var nom3 = 'an'+id;
    var mensual=$(nom1).val();
    var trimes = 0;
    var anual=0;
    trimes=mensual*3;
    anual=mensual*12;

    document.getElementById(nom2).value=trimes;
    document.getElementById(nom3).value=anual;
}
function Guardar(id){
    var nom1 = 'men'+id;
    var men =document.getElementById(nom1).value
    const datos={
        id: id,
        men: men
    };
    $.post('php/CambiarGasto.php',datos,function(response){
            
    });

}
