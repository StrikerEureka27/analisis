$(document).ready(function(){

    $('#search').keyup(function(){
        let search =  $('#search').val();
        console.log(search);
        $.ajax({
            url: 'php/busqueda-inventario.php', 
            type: 'POST', 
            data: { search },
            success: function(response){
                let clients =  JSON.parse(response);
                let template = '';
                clients.forEach(client =>{
                    template += `
                 <li class="list-group-item d-flex justify-content-between lh-condensed">
                     <div>
                         <h6 class="my-0 pb-1">${client.nombre}</h6>
                         <small class="text-muted">Cantidad: ${client.cantidad} </small>
                          <input type="text" id="cant" class="form-control" value="1" placeholder="" style="width: 50%;">
                     </div>
                     <button type="button" onClick="ingresarInsumo(${client.id},${client.cantidad})" class="btn btn-success"> <i class="fas fa-plus"></i> </button>
                 </li>
                    `
                });
                $('#lista-cliente').html(template);
            }
        })
     });


     $.ajax({
        url: 'php/cuenta-inventario.php',
        type: 'GET',
        success: function(r){
            let tasks = JSON.parse(r);
            let template = '';
            tasks.forEach(task =>{
                template = `
                <span  class="badge badge-secondary badge-pill">${task.numero}</span>
                `
          });
    
            $('#numero-reg').html(template);
         }
    
      })

})

function ingresarInsumo(id,canti){
    var cantidad = new Number(document.getElementById('cant').value);
    cantidad = cantidad + canti;
    console.log(cantidad);
    const data = {
        id: id,
        cantidad: cantidad
    }
    console.log(data);
    $.post('php/actualizar-insumo.php',data,function (response) {
        console.log(response);
    });

}